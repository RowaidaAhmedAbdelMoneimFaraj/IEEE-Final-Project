function chooseCookie(button) {
    const allItems = document.querySelectorAll(".cookie-item");
    const selectedItem = button.parentElement;
    allItems.forEach(item => {
        if (item !== selectedItem) {
            item.classList.add("blur");
        } else {
            item.classList.add("active");
        }
    });
    button.textContent = "Chosen ✅";
    button.classList.add("chosen");
}
function resetCookies() {
    const items = document.querySelectorAll(".cookie-item");
    const buttons = document.querySelectorAll(".cookie-item button");

    items.forEach(item => {
        item.classList.remove("blur", "active");
    });
    buttons.forEach(btn => {
        btn.textContent = "Choose";
        btn.classList.remove("chosen");
    });
}